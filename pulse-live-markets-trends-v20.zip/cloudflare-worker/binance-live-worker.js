// cloudflare-worker/binance-live-worker.js
//
// Cloudflare Workers port of netlify/functions/binance-live.js. Same
// signed proxy, same action allowlist, same "request-supplied credentials
// win over env vars" behavior. It exists as a separate deploy target
// because Netlify Functions on the free Starter plan always run from
// Columbus, Ohio (cmh) -- per-function region overrides are a Pro/
// Enterprise-only feature there, so the netlify.toml region pin in this
// repo is silently ignored on Starter, and Binance's own "b. Eligibility"
// rule (see https://www.binance.com/en/terms) blocks any request that
// arrives from a US-registered IP address regardless of where the actual
// person using the app is sitting. Cloudflare Workers instead execute at
// whichever edge location is nearest the incoming request, so a call from
// outside the US lands on Binance from outside the US too -- with no
// account/plan upgrade required. See LIVE-TRADING-SETUP.md for how to
// deploy this and point the app at it.
//
// Node's `crypto` module doesn't exist in Workers, so signing uses the Web
// Crypto API (crypto.subtle) instead -- that's the only functional
// difference from the Netlify version. Action allowlist, CORS handling,
// credential handling, error passthrough, and the userDataStream wsBase
// piggyback are all identical on purpose, so the app behaves the same
// regardless of which of the two this is pointed at.
//
// Supported actions (identical to the Netlify version):
//   account                 GET    /api/v3/account          — balances
//   openOrders               GET    /api/v3/openOrders       — open orders for a symbol
//   order                    POST   /api/v3/order             — place MARKET/LIMIT order
//   oco                      POST   /api/v3/orderList/oco     — place protective TP/SL pair
//   cancelOrder               DELETE /api/v3/order            — cancel a single order
//   cancelOrderList            DELETE /api/v3/orderList       — cancel an OCO pair
//   userDataStreamStart        POST   /api/v3/userDataStream  — get a listenKey
//   userDataStreamKeepalive    PUT    /api/v3/userDataStream  — required every <60min
//   userDataStreamClose        DELETE /api/v3/userDataStream
//
// SAFETY NOTE FOR WHOEVER EDITS THIS FILE: don't add an action that lets
// the client pass an arbitrary path — the allowlist below is what stops
// the client from ever making this call an endpoint it wasn't explicitly
// built for (e.g. a withdrawal endpoint).

const RECV_WINDOW = 5000;

const ACTIONS = {
  account:                { method: 'GET',    path: '/api/v3/account',         signed: true },
  openOrders:              { method: 'GET',    path: '/api/v3/openOrders',      signed: true },
  order:                   { method: 'POST',   path: '/api/v3/order',           signed: true },
  oco:                     { method: 'POST',   path: '/api/v3/orderList/oco',   signed: true },
  cancelOrder:              { method: 'DELETE', path: '/api/v3/order',          signed: true },
  cancelOrderList:          { method: 'DELETE', path: '/api/v3/orderList',      signed: true },
  userDataStreamStart:      { method: 'POST',   path: '/api/v3/userDataStream', userStream: true },
  userDataStreamKeepalive:  { method: 'PUT',    path: '/api/v3/userDataStream', userStream: true },
  userDataStreamClose:      { method: 'DELETE', path: '/api/v3/userDataStream', userStream: true },
};

function corsHeaders(origin, env) {
  const allowed = (env.ALLOWED_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
  const allowOrigin = allowed.length === 0 ? '*' : (allowed.includes(origin) ? origin : allowed[0]);
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };
}

function buildQuery(params) {
  const usp = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') usp.append(k, v);
  });
  return usp;
}

// Web Crypto's HMAC is async (no synchronous equivalent to Node's
// crypto.createHmac exists in Workers), so signing has one extra await
// compared to the Netlify version -- everything it produces is identical.
async function hmacSha256Hex(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sigBuf = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return Array.from(new Uint8Array(sigBuf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function sign(usp, apiSecret) {
  usp.append('timestamp', Date.now());
  usp.append('recvWindow', RECV_WINDOW);
  const qs = usp.toString();
  const signature = await hmacSha256Hex(apiSecret, qs);
  return qs + '&signature=' + signature;
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('origin') || request.headers.get('Origin') || '';
    const headers = corsHeaders(origin, env);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers });
    }

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return new Response(JSON.stringify({ error: 'Invalid JSON body' }), { status: 400, headers });
    }

    // Request-supplied credentials (typed into the app) win; Worker env
    // vars/secrets are only a fallback, same priority as the Netlify version.
    const apiKey = body.apiKey || env.BINANCE_API_KEY;
    const apiSecret = body.apiSecret || env.BINANCE_API_SECRET;

    if (!apiKey || !apiSecret) {
      return new Response(JSON.stringify({
        error: 'No Binance API key/secret provided.',
        code: 'NO_CREDENTIALS',
        howToFix: 'Enter your Binance API key and secret in the Live panel — they\u2019re sent with each request, never stored on the server.',
      }), { status: 400, headers });
    }

    const action = body.action;
    const def = ACTIONS[action];
    if (!def) {
      return new Response(JSON.stringify({ error: 'Unknown action: ' + action }), { status: 400, headers });
    }

    const BASE = env.BINANCE_API_BASE || 'https://api.binance.com';

    try {
      let url = BASE + def.path;
      const fetchOpts = { method: def.method, headers: { 'X-MBX-APIKEY': apiKey } };

      if (def.userStream) {
        // USER_STREAM endpoints take listenKey as a query param (for
        // keepalive/close) but need no signature at all.
        const usp = buildQuery(body.params);
        const qs = usp.toString();
        if (qs) url += '?' + qs;
      } else if (def.signed) {
        const usp = buildQuery(body.params);
        const signedQs = await sign(usp, apiSecret);
        if (def.method === 'GET' || def.method === 'DELETE') {
          url += '?' + signedQs;
        } else {
          fetchOpts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
          fetchOpts.body = signedQs;
        }
      }

      const resp = await fetch(url, fetchOpts);
      const text = await resp.text();

      // Piggyback the correct user-data WS host onto the listenKey
      // response, same as the Netlify version, so the client never has to
      // hardcode (and potentially mismatch) mainnet vs Testnet.
      if (action === 'userDataStreamStart' && resp.ok) {
        try {
          const parsed = JSON.parse(text);
          parsed.wsBase = BASE.includes('testnet.binance.vision')
            ? 'wss://stream.testnet.binance.vision'
            : 'wss://stream.binance.com:9443';
          return new Response(JSON.stringify(parsed), { status: resp.status, headers });
        } catch (e) {
          // fall through and relay the raw text below if Binance's
          // response wasn't valid JSON for some reason
        }
      }

      // Binance error bodies never contain the secret -- safe to relay
      // verbatim so the UI can show the real rejection reason.
      return new Response(text, { status: resp.status, headers });
    } catch (err) {
      return new Response(JSON.stringify({
        error: 'Upstream request to Binance failed',
        detail: String((err && err.message) || err),
      }), { status: 502, headers });
    }
  },
};
