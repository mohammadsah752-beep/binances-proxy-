// netlify/functions/binance-live.js
//
// Signed proxy for Binance Spot live trading. This still has to exist as a
// server — not a preference, a hard Binance constraint: Binance's own CORS
// policy explicitly does not allow the X-MBX-APIKEY header (or any signed
// request) from a browser origin. Binance's own developer docs say it
// directly: you cannot send a signed REST request from client end directly;
// you need a web server to forward it. Only their fully public (security
// type NONE) endpoints work straight from a browser — this app's live
// price feed already uses that path. Account balance, placing orders,
// cancelling, and the user-data listenKey are all SIGNED or USER_DATA/
// USER_STREAM endpoints, so none of them can go browser → Binance directly,
// no matter where the key and secret are typed in or stored. This function
// is the unavoidable relay for those.
//
// WHAT CHANGED (on request): BINANCE_API_KEY/BINANCE_API_SECRET are no
// longer read only from Netlify's environment variables. The client now
// sends { apiKey, apiSecret, action, params } with every call — the key and
// secret the person typed into the app itself (index.html stores them in
// localStorage on their own device, never in this repo). This function uses
// whatever it's handed per-request. Netlify env vars still work too, as a
// fallback, purely so anyone who set them up under the old instructions
// doesn't break — request-supplied credentials win if both are present.
//
// This function itself still never persists anything: it reads apiKey/
// apiSecret out of the request body, uses them to build one signed call to
// Binance, and forgets them the moment this invocation returns. Nothing is
// written to disk, a database, or a log here.
//
// The client (index.html) never gets BINANCE_API_SECRET back — it already
// has it (that's the whole point), but this function never echoes it in a
// response. It POSTs { apiKey, apiSecret, action, params } here; this
// function builds the exact signed request Binance expects, forwards it,
// and relays Binance's JSON response back (Binance's own error bodies don't
// contain the secret, so passing them through as-is is safe and helps
// debugging rejected orders).
//
// Supported actions:
//   account              GET  /api/v3/account            — balances
//   openOrders           GET  /api/v3/openOrders          — open orders for a symbol
//   order                POST /api/v3/order               — place MARKET/LIMIT order
//   oco                  POST /api/v3/orderList/oco       — place protective TP/SL pair
//                                                            (current endpoint — the old
//                                                            /api/v3/order/oco is deprecated)
//   cancelOrder           DELETE /api/v3/order             — cancel a single order
//   cancelOrderList       DELETE /api/v3/orderList         — cancel an OCO pair
//   userDataStreamStart   POST   /api/v3/userDataStream    — get a listenKey for the
//                                                            real-time fill/execution WS
//   userDataStreamKeepalive PUT  /api/v3/userDataStream    — required every <60min or
//                                                            Binance closes the stream
//   userDataStreamClose   DELETE /api/v3/userDataStream
//
// SAFETY NOTE FOR WHOEVER EDITS THIS FILE: don't add an action that lets the
// client pass an arbitrary path — the whole point of an allowlist below is
// that the client can never make this function call an endpoint it wasn't
// explicitly built for (e.g. a withdrawal endpoint).
//
// SECURITY MODEL, stated plainly: since the key/secret now travel with
// every request instead of living server-side, finding this function's URL
// alone gets an attacker nothing — they'd also need the actual key and
// secret, which live only in the browser storage of whichever device they
// were typed into. That's a real improvement over a permanently-configured
// server-side key (which meant the URL alone was enough). What it does NOT
// protect against: anyone who can read that device's browser storage (the
// device itself is compromised, a malicious browser extension with broad
// storage access, or a future bug in this app that lets attacker-controlled
// script run on the page) can read the key/secret directly — same as they
// could read any other password saved in that browser. Binance's own
// mandatory IP-restriction on the key (required the moment Spot & Margin
// Trading is enabled) still doesn't cover THIS function specifically, since
// requests to Binance still leave from this function's IP regardless of
// who triggered the call or where the credentials came from.

const crypto = require('crypto');

const BASE = process.env.BINANCE_API_BASE || 'https://api.binance.com';
const RECV_WINDOW = 5000;

// method: HTTP method. path: Binance REST path. signed: whether it needs
// timestamp+signature. userStream: uses X-MBX-APIKEY only, no HMAC (Binance
// treats USER_STREAM endpoints as key-only, not fully SIGNED).
const ACTIONS = {
  account:                { method: 'GET',    path: '/api/v3/account',          signed: true },
  openOrders:              { method: 'GET',    path: '/api/v3/openOrders',       signed: true },
  order:                   { method: 'POST',   path: '/api/v3/order',            signed: true },
  oco:                     { method: 'POST',   path: '/api/v3/orderList/oco',    signed: true },
  cancelOrder:              { method: 'DELETE', path: '/api/v3/order',           signed: true },
  cancelOrderList:          { method: 'DELETE', path: '/api/v3/orderList',       signed: true },
  userDataStreamStart:      { method: 'POST',   path: '/api/v3/userDataStream',  userStream: true },
  userDataStreamKeepalive:  { method: 'PUT',    path: '/api/v3/userDataStream',  userStream: true },
  userDataStreamClose:      { method: 'DELETE', path: '/api/v3/userDataStream',  userStream: true },
};

function corsHeaders(origin) {
  const allowed = (process.env.ALLOWED_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
  const allowOrigin = allowed.length === 0 ? '*' : (allowed.includes(origin) ? origin : allowed[0]);
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };
}

function buildQuery(params) {
  const usp = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') usp.append(k, v);
  });
  return usp;
}

function sign(usp, apiSecret) {
  usp.append('timestamp', Date.now());
  usp.append('recvWindow', RECV_WINDOW);
  const qs = usp.toString();
  const signature = crypto.createHmac('sha256', apiSecret).update(qs).digest('hex');
  return qs + '&signature=' + signature;
}

exports.handler = async (event) => {
  const origin = (event.headers && (event.headers.origin || event.headers.Origin)) || '';
  const headers = corsHeaders(origin);

  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };

  let body;
  try { body = JSON.parse(event.body || '{}'); } catch (e) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  // Request-supplied credentials (typed into the app) win; Netlify env vars
  // are only a fallback for anyone still set up the old way.
  const apiKey = body.apiKey || process.env.BINANCE_API_KEY;
  const apiSecret = body.apiSecret || process.env.BINANCE_API_SECRET;

  if (!apiKey || !apiSecret) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({
        error: 'No Binance API key/secret provided.',
        code: 'NO_CREDENTIALS',
        howToFix: 'Enter your Binance API key and secret in the Live panel — they\u2019re sent with each request, never stored on the server.',
      }),
    };
  }

  const action = body.action;
  const def = ACTIONS[action];
  if (!def) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Unknown action: ' + action }) };
  }

  try {
    let url = BASE + def.path;
    let fetchOpts = {
      method: def.method,
      headers: { 'X-MBX-APIKEY': apiKey },
    };

    if (def.userStream) {
      // USER_STREAM endpoints take listenKey as a query param (for
      // keepalive/close) but need no signature at all.
      const usp = buildQuery(body.params);
      const qs = usp.toString();
      if (qs) url += '?' + qs;
    } else if (def.signed) {
      const usp = buildQuery(body.params);
      const signedQs = sign(usp, apiSecret);
      if (def.method === 'GET' || def.method === 'DELETE') {
        url += '?' + signedQs;
      } else {
        fetchOpts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
        fetchOpts.body = signedQs;
      }
    }

    const resp = await fetch(url, fetchOpts);
    const text = await resp.text();

    // The user-data WebSocket host depends on which Binance environment
    // BINANCE_API_BASE points at (mainnet vs Testnet) — mainnet and Testnet
    // listenKeys are NOT interchangeable between their two WS servers, and
    // the client has no way to know which one this deployment is using.
    // Piggyback the correct host onto the listenKey response so the client
    // never has to hardcode (and potentially mismatch) it.
    if (action === 'userDataStreamStart' && resp.ok) {
      try {
        const parsed = JSON.parse(text);
        parsed.wsBase = BASE.includes('testnet.binance.vision')
          ? 'wss://stream.testnet.binance.vision'
          : 'wss://stream.binance.com:9443';
        return { statusCode: resp.status, headers, body: JSON.stringify(parsed) };
      } catch (e) {
        // fall through and relay the raw text below if Binance's response
        // wasn't valid JSON for some reason
      }
    }

    // Binance error bodies (e.g. {"code":-2010,"msg":"Account has insufficient balance..."})
    // never contain the secret — safe to relay verbatim so the client/UI can
    // show the real rejection reason instead of a generic failure.
    return { statusCode: resp.status, headers, body: text };
  } catch (err) {
    return { statusCode: 502, headers, body: JSON.stringify({ error: 'Upstream request to Binance failed', detail: String(err && err.message || err) }) };
  }
};
