
## Fixed: Binance "restricted location" block on Netlify's free plan — Cloudflare Worker option added

**The bug:** Connect kept failing with Binance's *"Service unavailable
from a restricted location according to 'b. Eligibility'"* even after a
previous pass added a `region = "sin"` pin to `netlify.toml`. Root cause:
per-function region overrides are a Netlify **Pro/Enterprise-only**
feature — on the free **Starter** plan that config block is silently
ignored at build time, so the function kept running from Netlify's US
default (Columbus, Ohio) and kept tripping Binance's own US-IP block,
independent of where the actual user is.

**The fix:**
- Added `cloudflare-worker/binance-live-worker.js` — a line-for-line port
  of `binance-live.js` (allowlist, CORS, credential handling, error
  passthrough, userDataStream `wsBase` piggyback all identical) rewritten
  for Cloudflare Workers, which run at whichever edge is nearest the
  request instead of one fixed region, so this sidesteps the Starter-plan
  limitation entirely at no cost. The one real difference: signing uses
  the Web Crypto API (`crypto.subtle`) since Node's `crypto` module isn't
  available in Workers.
- Added `cloudflare-worker/wrangler.toml` for one-command deploys via
  `wrangler deploy`.
- `index.html`: new **Proxy URL** field in the Live panel (below the API
  secret field, saved to this browser's `localStorage` alongside the
  credentials). Blank = keep using the built-in Netlify function
  (unchanged default behavior); paste a deployed Worker's URL to route
  `liveApiCall()` through it instead. `netlify.toml`'s `sin` region pin is
  left in place and still takes effect automatically for anyone who
  upgrades to Netlify Pro.
- `LIVE-TRADING-SETUP.md`: rewrote the troubleshooting section with the
  actual Cloudflare Workers deploy steps, plus an explicit note that if
  you're actually a US person (or on Binance's own List of Prohibited
  Countries), this isn't a bug to route around — Binance.US or a locally
  licensed exchange is the legitimate path there instead.

## API key/secret moved into the app itself — off Netlify's env vars

Requested: stop asking for `BINANCE_API_KEY`/`BINANCE_API_SECRET` to be set
up in Netlify's dashboard at all — put them directly in the app instead,
with live trading still actually working.

**The constraint this ran into:** Binance's own CORS policy explicitly
forbids the `X-MBX-APIKEY` header (and any signed request) from a browser
origin — their own developer docs say so directly: "you cannot send [a
signed] REST request from client end directly, instead you need to set up
your web server to forward your REST request." Only fully public
endpoints (this app's live price feed already uses that path) work
straight from a browser. That means account balance, placing orders,
cancelling, and the user-data listenKey were never going to be reachable
by pointing the browser at Binance directly, no matter where the key and
secret are typed in or stored — this is Binance's rule, not something
either side of this conversation could code around. A server relay,
specifically, stays mandatory.

**What actually changed, given that constraint:**
- `netlify/functions/binance-live.js` no longer requires
  `BINANCE_API_KEY`/`BINANCE_API_SECRET` as Netlify environment variables.
  The browser now sends `{ apiKey, apiSecret, action, params }` with every
  single call; the function uses whatever it's handed for that one request
  and never persists it (no logging, no disk, no database). Netlify env
  vars still work as a fallback, so anyone already set up the old way
  doesn't break — request-supplied credentials win if both are present.
- `index.html`: the old "Retry Connection" button is now two fields
  (**Binance API Key**, **Binance API Secret**) plus a **Connect** button.
  Submitting saves both to this browser's `localStorage`
  (`pulse_live_binance_creds_v1`) and immediately tries a real balance
  fetch to confirm they work. A **Forget saved key** link (shown once
  something's saved) clears them from this browser.
- `_liveReady`'s hard-failure trigger changed from HTTP 500 ("not
  configured" on the server) to the server's new `code: 'NO_CREDENTIALS'`
  (empty key/secret in the request) — otherwise identical logic to the
  previous pass: only a 401 (Binance itself rejecting the key) or
  `NO_CREDENTIALS` flips the connection state and pauses the Auto-Trader;
  every other error still only surfaces locally where it happened.
- `LIVE-TRADING-SETUP.md` rewritten around this flow, with the trade-off
  stated plainly rather than glossed over (see below).

**The trade-off, stated as directly as the setup doc states it:** removing
the permanently-configured server-side key is a real improvement — the
function's URL alone no longer gets an attacker anywhere, since they'd
also need the actual key/secret now. But those credentials live in this
browser's `localStorage` in plain text on whichever device they were typed
into — anyone who can get at that device (physical access, a malicious
browser extension with storage permissions, a future bug in this app that
lets attacker script run on the page) can read them directly, same as any
other saved password in that browser. That's a genuine, ongoing exposure
on that specific device, not a hypothetical one. This is the trade the
person explicitly asked for; it isn't presented as risk-free.

**Verification**: `node --check` on the rewritten function and the full
extracted script block, div-tag balance (292/292 — up from 289, from the
two new input fields + forget-link row), no duplicate element IDs, and a
full grep sweep confirming zero remaining references to the removed
`liveRetryBtn`/`SITE_ACCESS_TOKEN`/`_liveSiteToken` from prior passes. Not
verified: an actual live order or the CORS rejection itself (no network
access in this environment, and either needs a real Binance account
regardless) — the CORS behavior is sourced from Binance's own developer
community documentation, not independently reproduced here.

## Re-check pass on the Site Token removal — one real regression, fixed

Requested: check the previous change actually works, don't just assume it.
It didn't, fully — going through every path that touches `_liveReady`
turned up one real bug in what shipped as v8.

**The bug:** `refreshLiveBalances()` is called from more places than just
boot/Retry — it also runs after every order fill and every position close
(`attachProtectiveOco`, `recordLiveClose`, the manual/auto order success
paths) purely to refresh the displayed balance numbers. v8's version of
that function treated *any* failure there — including a one-off network
blip or a transient upstream error, not just a real "keys are gone"
failure — as a reason to flip the whole panel to disconnected, hide the
balances, and silently switch the Auto-Trader off. A single flaky call
moments after a fill could have killed an otherwise-healthy live session
with no real cause.

**The fix:** the two failure modes that actually mean "this isn't working"
— Binance itself returning 401 (bad key/IP/permissions) or this proxy's
own 500 (`BINANCE_API_KEY`/`SECRET` not set — the only thing that ever
returns 500) — are now detected once, centrally, in `liveApiCall` itself,
so they're caught no matter which action triggers them, and only those
two flip `_liveReady`, update the gate note/Retry button, and pause the
Auto-Trader. Every other error (502 upstream, a timeout, Binance rejecting
one specific order for its own reasons like insufficient balance) now
only surfaces locally where that call happened — same as it worked before
the Site Token existed at all — and leaves an already-good connection
alone.

**Verification**: traced every call site of `_liveReady`,
`refreshLiveBalances()`, and `liveApiCall()` by hand against this specific
failure-mode split, plus the same `node --check` / div-balance / duplicate-
ID sweep as before.

## Removed the Site Token gate — Live panel now works directly off Binance keys

Requested: the "Site Token" step was confusing (it's unrelated to whether
Binance is actually configured) and unwanted — drop it, make the Live
panel work directly off `BINANCE_API_KEY`/`BINANCE_API_SECRET` alone.

**What changed:**
- Removed the `SITE_ACCESS_TOKEN` check from `netlify/functions/binance-live.js`
  entirely (previously optional — only enforced if the env var was set).
  The function's only remaining gate is the pre-existing one: no
  `BINANCE_API_KEY`/`BINANCE_API_SECRET`, no trading (500, clear error).
- Removed the "Site Token" input, the "Unlock Live Trading" button, and
  all client-side token state (`_liveSiteToken`, the `X-Site-Token`
  header, `localStorage['pulse_site_token']`) from `index.html`. The
  panel now calls the function directly on load; a boolean `_liveReady`
  (true once an `account` call actually succeeds) drives everything that
  used to check the token — balances, manual orders, and the Auto-Trader
  toggle all gate on that instead.
- Added a **Retry Connection** button in place of Unlock — shown only
  when not connected, so there's still a manual re-check after fixing env
  vars, without a page reload.
- Updated `LIVE-TRADING-SETUP.md` and this README to match; the old
  `SITE_ACCESS_TOKEN` row is gone from the setup table.

**Trade-off, stated plainly:** the reason that token existed was that
this function has no login system, and CORS doesn't stop a direct
request to its URL (only a browser's own fetch is CORS-restricted).
Removing it means anyone who finds the function's URL can call it
directly and it will use your real Binance key — that risk is real, not
theoretical, and it's back after this change. `ALLOWED_ORIGIN` still
restricts what a *browser* can read back but doesn't stop a direct
non-browser request. Binance's own mandatory IP-restriction on the key
doesn't help here either, since requests still leave from this same
Netlify function's IP regardless of who triggered the call. If that
residual exposure matters later, the cheapest fix is Netlify's own
site-level **Visitor access** password (Site configuration → Visitor
access) in front of the whole site, rather than reintroducing an in-app
token.

**Verification**: `node --check` on the function and the extracted
script block, div-tag balance diffed (289/289), and grepped for every
remaining reference to the removed token variables/UI ids (`_liveSiteToken`,
`liveTokenInput`, `liveUnlockBtn`, `pulse_site_token`, `X-Site-Token`,
`SITE_ACCESS_TOKEN`) to confirm none were missed. Not verified: an actual
live order (no network access here, and it needs a real account
regardless) — Testnet first, as before.

## Short positions could close tagged "TAKE PROFIT" while actually losing money

Caught directly from a live screenshot, not by code inspection first — a
demo SHORT closed within the same minute it opened, tagged **TAKE
PROFIT**, showing **-$19.08**. A take-profit closing at a loss is a
contradiction, so this was checked against the underlying math rather
than trusted at face value.

**The PnL number itself was correct** — `(entry - exit) * qty` on a
short that moved against it (price rose) is genuinely negative; that
part of the engine was never wrong. **The label was wrong**, and tracing
why turned up two related gaps:

- **Auto-Risk sizing mode** validates that a Stop Loss sits on the
  correct side of entry for the chosen direction (a long's SL below, a
  short's above) — but had no equivalent check for Take Profit, on
  either side of that branch.
- **Manual sizing mode** had no direction validation at all, for either
  TP or SL. It only had the liquidation-distance check (added in an
  earlier pass) — which compares *how far* a price is from entry, not
  *which side* of entry it's on, so it doesn't catch a wrong-direction
  value either.

The likely trigger: `autoFillRiskDefaults()` only fills TP/SL fields
when they're *empty* — by design, so it never overwrites something the
person deliberately typed. But that means switching the side toggle
(Long → Short or back) without clearing those fields leaves whatever was
there from the *previous* direction in place. `checkFuturesTriggers()`
itself compares direction correctly (a short's TP fires on `price <=
tp`) — so a long-style TP sitting *above* entry on a short satisfies
that short's own TP condition on the very first uptick, closing it
immediately, tagged as its own take-profit firing, regardless of
whether the position was actually up or down.

**Fix**: both sizing modes now reject the order outright — before any
money moves — if TP or SL is on the wrong side of entry for the chosen
direction, with a message naming which field and which side it needs to
be on. This is a hard stop, not a silent correction, since silently
flipping or discarding a price the person actually typed would be its
own kind of surprise.

**Verification**: `node --check` clean; div balance unchanged (290/290);
confirmed the third `openFuturesPosition()` call site (the one-tap
"execute this suggested trade" button) was never exposed to this,
since it computes TP/SL fresh from `side` on every tap rather than
reading persisted form fields.

## Deep systemic audit — full pass across the engine

Requested as a full audit, not a point fix: every function's reachability,
every DOM id the JS looks up, every localStorage key, every WS/REST
fallback chain, and the client↔server contract with `binance-live.js`.

**Confirms the ROE diagnosis was right, not just plausible.** Both spots
that reference "the Demo Trading Account's live-refresh loop" inside
`fetchMarketPricesWithCache()` (the loading-spinner-suppression comment,
and the cache-bypass comment on `force`) talk about that loop as if it
already existed. It didn't — nothing anywhere called this function on a
recurring timer. A previous pass clearly built the plumbing for this fix
(the `force` parameter, the spinner suppression so a background refresh
wouldn't shift the layout) and then never wrote the interval that was
supposed to use it. That's the direct cause of the frozen-price bug: not
a math error, a documented feature that was half-wired.

**New findings from this pass, on top of the ROE fix:**

1. **Real Live Trading feed had the same freeze risk, worse.** The
   phone-lock/unlock recovery handler (`visibilitychange`) only ever
   restarted the paper-trading demo feed. The real-money Live Trading
   WebSocket was never restarted there — only a manual tab-switch away
   and back would revive it. A position could sit priced at whatever it
   was when the phone was locked, with no visible sign the feed was dead.
   Fixed: both feeds now restart together, and both accounts force one
   immediate render on return.

2. **Manual Sell left protective OCOs dangling on Binance (most severe
   finding).** Selling out of a position by hand never cancelled the
   resting take-profit/stop-loss bracket order placed on the way in.
   That order doesn't self-cancel just because the coins it was guarding
   got sold another way — it keeps resting on the exchange. Best case:
   a rejected order days later for no visible reason. Worst case: a
   *new* position opened afterward gets closed out from under the user
   by a stale OCO left over from an unrelated trade. `_liveOpenPositions`
   tracking had the same gap client-side, so the panel kept showing a
   sold position as still open. Fixed for both the immediate-fill path
   (market order) and the delayed-fill path (a resting limit order that
   fills later via the execution-report stream) — a manual sell now
   cancels any resting OCO it should supersede, in both cases only
   *after* the sell itself is confirmed filled, so a failed sell attempt
   never leaves a position OCO-less for nothing.

3. **The new 15s fallback refresh (fix #1) skipped stop-loss/take-profit
   checks.** `fetchMarketPricesWithCache()` only ever calls
   `renderFuturesAccount()` on completion — it was never wired to also
   call `checkFuturesTriggers()`, unlike the WS tick path and the
   Binance-REST fallback poll, both of which go through
   `scheduleFuturesRender()` and check triggers on every update. Once
   fix #1 made this fallback move the price again, that gap became live:
   a paper position's SL/TP could sit crossed-but-unclosed for up to 15s
   at a time whenever this third-tier fallback was the only thing moving
   the price. Fixed in the same interval — trigger check now runs right
   after each fallback price refresh.

**Checked and confirmed clean:** all 123 functions in the script are
reachable from somewhere (no dead code); no function call resolves to an
undefined identifier; every `getElementById`/`querySelector('#…')` target
in the JS exists as a real element (113 of 114, the one exception is a
dynamically-created `<style>` tag whose id is set in the same code that
looks it up); no duplicate DOM ids anywhere in the file; the four
localStorage keys in use (`MARKET_CACHE_KEY`, `FUT_ACCOUNT_KEY`,
`LIVE_HISTORY_KEY`, `LIVE_DAILY_KEY`) are each unique; every
`liveApiCall()` action the client sends (`account`, `order`, `oco`,
`userDataStreamStart/Keepalive/Close`, and now `cancelOrderList`) is
implemented server-side in `binance-live.js`'s allowlist; the
listen-key keepalive (every 30 min, under Binance's 60 min limit) and
its start/stop lifecycle are symmetric; Chart.js's lazy-load path is
correctly gated behind `typeof Chart === 'undefined'`; no conflicting
duplicate CSS rules.

**Noted, not changed — worth your call rather than an unasked-for feature
add:**
- The server supports `openOrders` and single-order `cancelOrder`, but
  there's no UI to view or cancel a resting *unfilled* limit order before
  it fills. Lower risk than the OCO issue (a resting limit just fills at
  the price you set, it doesn't silently endanger an unrelated position),
  so left alone rather than building order-management UI you didn't ask
  for.
- The third-tier CoinGecko fallback (fix #1) refreshes the raw price
  (and now checks triggers) but doesn't backfill the OHLC candle array
  the EMA/RSI/Strategy-Scan panels use — those can go stale during a
  full Binance outage (WS *and* REST both down, i.e. two fallback tiers
  already failed). Lower priority than the trigger-check gap since it's
  a display staleness, not a correctness issue with money on the line.

## ROE stuck at 0.00% — Mark price fallback was a frozen one-time snapshot
Reported: paper-trading (demo $300) positions showed +$0.00 / 0.00% ROE
no matter how long they were held, even across trades opened and closed
20 minutes apart — all three trade-history entries priced at the exact
same value.

**Root cause**: `getFuturesMarkPrice()`'s only source when Binance's
WebSocket AND its REST poll are both unreachable (geo-restricted network,
carrier block, firewall — the WS goes straight to `fstream.binance.com`
from the browser, no server-side proxy in front of it) is the
CoinGecko-sourced spot cache (`MARKET_CACHE_KEY`). That cache was written
once on page load, a refresh-button tap, or switching onto the Markets
tab — nothing re-fetched it on a timer. On a session where Binance never
connects even once, every position's Mark price stayed pinned to the
single CoinGecko snapshot fetched at page load, for the rest of the
session: open price == mark price == close price, forever. `pnl = (mark -
entry) * qty` is exactly `$0` when mark equals entry, and ROE inherits
that. This wasn't a rounding or math bug — the PnL formula itself was
already correct; the number it was fed just never changed.

**Fix**: `startFuturesFallbackPriceRefresh()` — a 15s interval, started/
stopped alongside the WS itself (`startFuturesLiveData`/
`stopFuturesLiveData`, so it's live exactly when the feed should be:
page boot, Markets tab switch, tab-visibility recovery), that re-polls
CoinGecko *only* while `_futConnState !== 'connected'`. Once the real WS
is healthy it's a no-op, so this adds zero extra network traffic on top
of an already-live feed — it only kicks in as a genuine second line of
defense when Binance is unreachable, so Mark price keeps moving (at
~15s granularity instead of tick-by-tick) instead of freezing outright.

**Verification**: `node --check` on the extracted `<script>` block
(clean); div-tag balance unchanged (290/290); grepped every call site of
`startFuturesLiveData`/`stopFuturesLiveData` (boot, tab-switch,
visibility-change recovery) to confirm all three now pick up the fix
through the same two wrapper functions rather than needing a separate
patch at each site. Not verified: an actual sustained Binance outage
against the live deployment — no network access in this environment to
simulate that; the fix is a straightforward re-fetch-on-a-timer, and the
existing CoinGecko fetch path it reuses (`fetchMarketPricesWithCache`)
was already exercised by the tab-switch/refresh-button call sites.

## Live Trading review pass — one critical fix, several real correctness bugs
Requested: check the whole Live Trading feature carefully for bugs and fix
them before it touches real size. Went through every function against the
actual Binance execution-report/OCO field shapes and the concurrency paths
(rapid tab-switching, a second order landing before the first resolves,
manual + Auto-Trader running at once), not just a syntax pass.

**Critical — the proxy had no caller authentication.** CORS does not
protect a server endpoint from direct requests; it only restricts what a
*browser* is allowed to read back, and only for browser-JS callers. A
direct request (curl, another server, a bot) bypasses it completely. As
shipped, `netlify/functions/binance-live.js` would use Ahdus's real
Binance key for whoever POSTed to its URL — no login system exists
anywhere else in this app to have caught that. Fixed by adding
`SITE_ACCESS_TOKEN`: a required, constant-time-compared shared secret the
function now checks before doing anything, failing closed (refuses every
request) if the variable isn't set rather than quietly running open. The
client never stores it — the Live panel now has an Unlock control that
holds it in memory for the session only. See LIVE-TRADING-SETUP.md.

**Real bugs, not just theoretical:**
- A second protected order (manual or auto) placed before an earlier
  unfilled LIMIT buy resolved overwrote the single tracking slot that
  remembered its TP/SL — so the first order, once it eventually filled,
  could complete with **no OCO ever attached and no error shown**. Same
  single-slot problem let a manual position and an Auto-Trader position
  clobber each other's P&L/close tracking if both were open at once.
  Fixed by keying pending-protection and open-position tracking off
  `clientOrderId` / `orderListId` instead of one shared variable, tagged
  by source (`manual`/`auto`) so the Auto-Trader's one-position-at-a-time
  rule still holds without affecting manual orders.
- `startLiveUserStream()` had no reentrancy guard — calling it twice in
  quick succession (rapid tab-switching, or the unlock flow racing the
  boot flow) opened two authenticated streams and leaked a `listenKey`
  with no reference left to close it. Added a start-in-progress guard.
- "BTC Held" read Binance's `free` balance only, which excludes whatever's
  reserved in an open OCO leg — so a protected position's BTC looked like
  it had vanished from the balance display, and the circuit breaker's
  equity estimate was quietly understated the same way. Now tracks and
  displays `free + locked`, labeled.
- Sell + Take Profit/Stop Loss together did nothing (Spot has no short to
  protect on a Sell) but the ticket let you fill in TP/SL fields on that
  side anyway with no feedback that they'd be ignored. Now clears/hides
  that section when Sell is selected.
- Entry price used for OCO placement and P&L was whatever the ticker
  happened to read a moment after the fill, not the actual fill price.
  Now uses the real average fill price from the order response
  (`cummulativeQuoteQty / executedQty`) or the execution report's own
  cumulative fields.

**Verification**: same as before (`node --check` on the function and the
extracted script block, div-tag balance diffed, duplicate-ID grep) plus
this pass's specific target — grepped for every remaining reference to the
old single-slot tracking variables to confirm none were missed in the
refactor. Still not verified: an actual live order (no network access
here, and it needs a real account regardless) — Testnet first, as before.

## Live Trading — real Binance Spot balance, real orders, optional Auto-Trader
Scope first, because it changes something this README already claimed
elsewhere: the "No Auto-Execute" How It Works card previously said nothing
in this app opens a trade without a tap. That's still true for the $300
paper account and for the new Live panel's manual ticket — it is no longer
true unconditionally, because this release adds one opt-in exception (the
Auto-Trader, off by default). Updated that card's copy in the same change
rather than let it go stale.

**What was asked**: wire a Binance-style Spot order ticket (Buy/Sell,
Limit/Market, TP/SL with Advanced SL Limit/SL Market, Iceberg, live order
book) into the app with real-time data, then move from the paper balance
to a real one and have it place real trades with no manual tap.

**What shipped**:
- `netlify/functions/binance-live.js` (new — this project had no
  `netlify/functions/` before this change): signed proxy for Binance Spot
  REST. `BINANCE_API_KEY`/`BINANCE_API_SECRET` live in Netlify env vars
  only, read server-side, never sent to the client — same pattern the
  parent MINDBOX/COO-COO project uses for its AI provider keys, applied
  here from the start. Allowlisted actions only (account, openOrders,
  order, oco via the current `/api/v3/orderList/oco` endpoint — the old
  `/api/v3/order/oco` is deprecated — cancelOrder, cancelOrderList, and
  the user-data-stream listenKey lifecycle). See LIVE-TRADING-SETUP.md.
- A new `.live-account` panel, separate from `.fut-account` (own WS
  connection to genuine Spot streams, own candle store, own storage keys)
  so nothing here can touch or reset the paper simulator.
- Manual order ticket matching the screenshot: Buy/Sell tabs, Limit/Market,
  Price/Amount/Total (computed both directions), TP/SL Advanced (TP Limit,
  SL Trigger + SL Limit/SL Market toggle → real OCO order), Iceberg
  (icebergQty, Limit-only per Binance's own rule), live order book.
- Auto-Trader (off by default every page load): EMA50/EMA200 bullish-cross
  entry on live 1m candles, RSI(14) overbought filter, 1.5x/3x ATR SL/TP
  (same ratio `autoFillRiskDefaults()` already uses), position sized off a
  configurable % risk of available balance. Long-only — Spot has no margin
  to short against. A real OCO is placed the moment an entry fills (via
  the account's user-data-stream, real-time, not polling), so protection
  stands even if the tab closes afterward; only new entries need the tab
  open. Daily-loss circuit breaker auto-pauses it and requires a manual
  re-enable.
- Exchange filters (`LOT_SIZE`/`PRICE_FILTER`/`NOTIONAL`) fetched once and
  used to round every quantity/price before it's ever sent, so orders
  don't get rejected for a step-size/tick-size/minimum-notional mismatch.

**Verification**: `node --check` on the new function file and on the
extracted inline `<script>` block (both clean); div-tag balance diffed
before/after (282/282, unchanged delta from the insertion); grep-checked
for duplicate element IDs across the file (none). Not verified: an actual
live order against a real Binance account — this environment has no
network access to test that, and it needs a real API key regardless. Test
on Testnet first (`BINANCE_API_BASE`, see LIVE-TRADING-SETUP.md).

**Out of scope this pass**: ETH/SOL on the Live panel (BTC/USDT only, same
as the reference screenshot); true tab-closed 24/7 auto-execution (would
need a small always-on process — Netlify Scheduled Functions can't hold a
live WebSocket open, bottoming out around 1-minute cron cadence, so they
can't reproduce real-time tick-driven entries the way this does); trading
fees are not netted out of the P/L shown in the Live Trade Log.

Clarified scope first: this is specifically about the existing Auto-Risk
"2% equity" sizing mode — not an auto-execute bot. Nothing here opens a
trade by itself; Open Long/Open Short still always requires an explicit
tap, same as every other trade in this panel (see the "No Auto-Execute"
card in How It Works, unchanged).

**Before**: switching to Auto sizing mode required typing a Stop Loss
yourself before `calculateFuturesRiskMetrics()` would return anything —
until then the whole HUD sat on "—" placeholders and Open Long/Open Short
stayed disabled.

**Now**: `autoFillRiskDefaults()` auto-populates a starting SL/TP the
moment Auto mode is switched on, or the asset changes while already in it:
- Same 1.5x-ATR-stop / 3x-ATR-target formula the existing ATR "Prefill"
  button already used (a volatility-scaled 2:1 reward:risk distance, not
  an arbitrary flat percent) — reuses the ATR/EMA trend the signal panel
  already computes rather than recomputing it.
- Biased toward the live EMA50/EMA200 trend when one's resolved; defaults
  long-style if the trend is still building.
- Falls back to 1% of price for the stop distance if ATR hasn't finished
  computing yet (fresh asset, still building candle history), so it never
  just sits blank waiting on the signal panel to load.
- Never overwrites a value already typed into either field — only fills a
  genuinely empty form.

Unit-tested the pure math directly (bullish → long-style SL/TP, bearish →
short-style, no-cached-signal ATR fallback, existing-input is respected,
no-live-price degrades to a no-op) before touching the live file — all
five cases matched hand-calculated expected values. Diffed against the
previous build to confirm the only changes are this function, its two call
sites (sizing-mode toggle, asset switch), and the signal-panel cache it
reads from.
