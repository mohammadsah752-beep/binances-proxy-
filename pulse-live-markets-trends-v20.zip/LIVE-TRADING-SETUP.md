# Live Trading Setup

The Live Trading panel (real Binance Spot balance, real orders) needs a
Binance API key with **Enable Spot & Margin Trading** permission. You type
the key and secret directly into the app now — they're kept in this
browser's storage (`localStorage`) on your own device, not in Netlify's
dashboard and not in this repo. `netlify/functions/binance-live.js` still
receives them with every request and signs the actual call to Binance, but
it never writes them anywhere — no logging, no persistence, no env vars
required. See that file's own header comment for exactly why a server
still has to be in the loop at all (short version: Binance's own CORS
policy blocks signed requests from a browser origin outright — that's
Binance's rule, not something either of us can route around from here).

On Netlify's free Starter plan, that function runs from a US datacenter
by default, which trips Binance's own US-eligibility block regardless of
where you actually are — see the **Troubleshooting** section below for
the Cloudflare Workers alternative (`cloudflare-worker/`) if you hit that.

## 1. Create the API key on Binance

Binance → Profile → API Management → Create API. Restrictions to set:

- **Enable Reading** — on
- **Enable Spot & Margin Trading** — on
- **Enable Withdrawals** — leave **off**. This app never needs it, and
  leaving it off means even a fully compromised key can't move funds out
  of the account, only trade within it.
- **IP access restriction — this one is not optional on current Binance
  accounts.** Binance now auto-deletes any key that has "Unrestricted"
  IP access *and* any permission beyond Reading enabled. So the moment
  Spot & Margin Trading is checked, "Unrestricted" isn't a looser option
  you can pick — it gets the key deleted outright. You must set
  "Restrict access to trusted IPs only" and enter a real IP. Netlify
  Functions don't have a fixed outbound IP by default, so you need
  either Netlify's static IP add-on, or a small proxy with a known IP
  that this function calls through, before you have an IP to whitelist.

## 2. Enter it in the app — nothing to set up on Netlify

Open the Live panel → **Binance API Key** / **Binance API Secret** fields →
paste both → **Connect**. That's it. The balance should populate within a
few seconds. An error there is either Binance's own rejection reason (bad
key, wrong permissions, IP restriction, etc.) passed straight through, or
"No Binance API key/secret provided" if the fields are empty — both
specific enough to act on.

The key/secret are saved to this browser's `localStorage` the moment you
hit Connect, so you don't have to re-enter them next time you open the app
**on this same device/browser**. Use **Forget saved key** (appears once
something's saved) to wipe them from this browser — useful before handing
the device to anyone else, or if you ever want to rotate the key.

Two optional Netlify environment variables still matter, since they're
read on the server side and can't go in the app's UI:

| Key | Value |
|---|---|
| `ALLOWED_ORIGIN` | optional — your deployed site's origin, e.g. `https://pulse-yoursite.netlify.app`. Restricts what a *browser* can read from the function; see the security note below for what it doesn't cover. |
| `BINANCE_API_BASE` | optional — defaults to `https://api.binance.com`. Set to `https://testnet.binance.vision` to point the whole panel at Binance's Spot Testnet (fake funds, real API flow) instead of the live exchange, with no code changes. |

(`BINANCE_API_KEY`/`BINANCE_API_SECRET` as Netlify env vars still work too,
as a fallback, purely for anyone who set the app up under the old
instructions — the key/secret typed into the app take priority over those
if both happen to be present.)

### Security note — read this before you paste a real key in

Typing the key/secret into the app instead of Netlify's dashboard is a
real trade-off, not a free upgrade:

- **What's better:** there's no longer a permanently-configured server-side
  key. Earlier versions kept `BINANCE_API_KEY`/`SECRET` in Netlify's env
  vars, which meant anyone who found the function's URL could trade with
  your money using no credentials of their own — CORS doesn't stop a
  direct (non-browser) request, only a browser's own fetch is
  CORS-restricted. Now the URL alone gets an attacker nothing; they'd also
  need the actual key and secret.
- **What's the same or worse:** those credentials now live in this
  browser's `localStorage`, in plain text, on whichever device you typed
  them into. Anyone who can get at that device — physical access, a
  malicious browser extension with storage permissions, or (hypothetically)
  a future bug in this app's own code that lets attacker script run on the
  page — can read them directly, same as any other password saved in that
  browser. That's a real, ongoing exposure on your device specifically,
  for as long as the key sits there.
- If that trade-off doesn't sit right with you, **Forget saved key** after
  each session is the mitigation — you'll just need to re-paste both
  values next time.

## 3. First load after deploying

- The Auto-Trader toggle defaults to **Paused** every time the page loads,
  regardless of how it was left last session. Flip it on deliberately each
  session you want it running.
- Try Testnet first (`BINANCE_API_BASE` above) if this is the first time
  this code is touching a real order — it exercises the exact same
  signing/order/OCO code path against fake funds before any real money is
  at risk.

## Troubleshooting: "Service unavailable from a restricted location"

If Connect fails with *"Service unavailable from a restricted location
according to 'b. Eligibility'..."*, that message is coming straight from
Binance, not from this app — Binance is refusing the request based on
where it physically originated.

**Why this happens even if you're nowhere near the US:** Netlify Functions
deploy to Ohio, USA (`cmh`) by default. Binance.com blocks connections
from US-registered IP addresses under its own Terms of Use, since US
persons/traffic are required to use the separate Binance.US platform
instead. So `binance-live.js`'s calls to Binance were leaving from a US
address and getting blocked there — independent of your own location. (If
you *are* actually a US person or based somewhere else on Binance's [List
of Prohibited Countries](https://www.binance.com/en/legal/list-of-prohibited-countries),
this isn't a bug to route around — Binance.US, or a locally licensed
exchange, is the legitimate path instead.)

**Why the region pin in `netlify.toml` doesn't fix it:** per-function
region configuration is a Netlify **Pro or Enterprise plan** feature — on
the free **Starter** plan, that `[functions.binance-live]` block is
silently ignored at build time and the function stays on the US default
no matter what region it names. There's no error or warning when this
happens; it just doesn't take effect. Check **Project configuration →
Build & deploy → Continuous deployment → Functions region** in the
Netlify dashboard to confirm — if it says a US region (or doesn't list an
override at all), that's this.

**The actual fix on the free plan — move the proxy to Cloudflare
Workers:**

Cloudflare Workers run at whichever edge location is nearest the
incoming request rather than one fixed region, so this sidesteps the
Netlify Starter limitation entirely, at no cost.

1. Sign up for Cloudflare (free) at https://dash.cloudflare.com/sign-up
   if you don't have an account.
2. In the dashboard: **Workers & Pages → Create → Create Worker**. Give
   it any name (e.g. `pulse-binance-live`) and deploy the default
   "Hello World" template — you'll replace the code next.
3. Open the Worker → **Edit code**, delete everything in the editor, and
   paste in the full contents of `cloudflare-worker/binance-live-worker.js`
   from this repo. Save and deploy.
   - Prefer the command line? `cd cloudflare-worker && npx wrangler deploy`
     works too, using the `wrangler.toml` already in that folder — no
     separate account setup beyond `wrangler login`.
4. Copy the Worker's URL from the dashboard (looks like
   `https://pulse-binance-live.yoursubdomain.workers.dev`).
5. In the app's Live panel, paste that URL into the new **Proxy URL**
   field (below the API secret field) and hit **Connect** again. Leave it
   blank to keep using the built-in Netlify function.

Optional: if you want `ALLOWED_ORIGIN` or `BINANCE_API_BASE` (e.g. to
point at Testnet) on the Worker, set them under the Worker's **Settings →
Variables**, or uncomment the `[vars]` block in `wrangler.toml` before
running `wrangler deploy`. They work the same way as on the Netlify
function.

## What this does NOT do

- It does not run with the tab closed. Entries are decided by live
  WebSocket ticks in the browser — there's no server-side bot running
  24/7. Once a position is open, its TP/SL is a real order sitting on
  Binance, so *that* part does survive the tab closing; new entries do not
  happen until the tab is open again.
- It does not guarantee profitable trades, and it isn't financial advice
  — the Auto-Trader is a plain EMA50/EMA200 crossover, not a backtested or
  vetted strategy.
