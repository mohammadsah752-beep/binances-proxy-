// oracle-vm-proxy/server.js
//
// Same signing logic and same request/response shape as
// cloudflare-worker/binance-live-worker.js, ported to plain Node.js so it
// can run as an always-on process on a dedicated VM instead of a
// shared-IP serverless function. Zero npm dependencies on purpose --
// only Node's own http/https/crypto/url modules -- so `npm install`
// isn't a step that can fail or drift on a fresh server.
'use strict';

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { URL, URLSearchParams } = require('url');

const PORT = process.env.PORT || 8080;
const RECV_WINDOW = 5000;
const BINANCE_BASE = process.env.BINANCE_API_BASE || 'https://api.binance.com';
const BROWSER_USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const ACTIONS = {
  account:                 { method: 'GET',    path: '/api/v3/account',         signed: true },
  openOrders:               { method: 'GET',    path: '/api/v3/openOrders',      signed: true },
  order:                    { method: 'POST',   path: '/api/v3/order',           signed: true },
  oco:                      { method: 'POST',   path: '/api/v3/orderList/oco',   signed: true },
  cancelOrder:               { method: 'DELETE', path: '/api/v3/order',          signed: true },
  cancelOrderList:           { method: 'DELETE', path: '/api/v3/orderList',      signed: true },
  userDataStreamStart:       { method: 'POST',   path: '/api/v3/userDataStream', userStream: true },
  userDataStreamKeepalive:   { method: 'PUT',    path: '/api/v3/userDataStream', userStream: true },
  userDataStreamClose:       { method: 'DELETE', path: '/api/v3/userDataStream', userStream: true },
};

function buildQuery(params) {
  const usp = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') usp.append(k, String(v));
  });
  return usp;
}

function sign(usp, secret) {
  usp.append('timestamp', Date.now());
  usp.append('recvWindow', RECV_WINDOW);
  const qs = usp.toString();
  const signature = crypto.createHmac('sha256', secret).update(qs).digest('hex');
  return qs + '&signature=' + signature;
}

function callBinance(method, path, extraHeaders, body) {
  return new Promise((resolve, reject) => {
    const target = new URL(BINANCE_BASE + path);
    const headers = Object.assign({ 'User-Agent': BROWSER_USER_AGENT }, extraHeaders);
    if (body) headers['Content-Length'] = Buffer.byteLength(body);
    const req = https.request(target, { method, headers }, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.setTimeout(10000, () => req.destroy(new Error('Binance request timed out')));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

function sendJson(res, status, obj) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(obj));
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }
  if (req.method !== 'POST') {
    return sendJson(res, 405, { error: 'Method not allowed' });
  }

  let raw = '';
  req.on('data', (c) => {
    raw += c;
    if (raw.length > 1e6) req.destroy(); // guard against runaway bodies
  });
  req.on('end', async () => {
    let body;
    try {
      body = JSON.parse(raw);
    } catch (e) {
      return sendJson(res, 400, { error: 'Invalid JSON body' });
    }

    const { action, params, apiKey, apiSecret } = body;
    if (!apiKey || !apiSecret) {
      return sendJson(res, 400, {
        error: 'No Binance API key/secret provided.',
        code: 'NO_CREDENTIALS',
        howToFix:
          'Enter your Binance API key and secret in the Live panel — they are sent with each request, never stored on this server.',
      });
    }

    const def = ACTIONS[action];
    if (!def) return sendJson(res, 400, { error: 'Unknown action: ' + action });

    try {
      let path = def.path;
      const headers = { 'X-MBX-APIKEY': apiKey };
      let outBody = null;

      if (def.userStream) {
        const usp = buildQuery(params);
        const qs = usp.toString();
        if (qs) path += '?' + qs;
      } else if (def.signed) {
        const usp = buildQuery(params);
        const signedQs = sign(usp, apiSecret);
        if (def.method === 'GET' || def.method === 'DELETE') {
          path += '?' + signedQs;
        } else {
          headers['Content-Type'] = 'application/x-www-form-urlencoded';
          outBody = signedQs;
        }
      }

      const upstream = await callBinance(def.method, path, headers, outBody);
      let payload = upstream.body;

      if (action === 'userDataStreamStart' && upstream.status < 300) {
        try {
          const parsed = JSON.parse(payload);
          parsed.wsBase = BINANCE_BASE.includes('testnet.binance.vision')
            ? 'wss://stream.testnet.binance.vision'
            : 'wss://stream.binance.com:9443';
          payload = JSON.stringify(parsed);
        } catch (e) {
          /* leave payload as-is if it wasn't JSON */
        }
      }

      res.writeHead(upstream.status, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      });
      res.end(payload);
    } catch (err) {
      sendJson(res, 502, {
        error: 'Upstream request to Binance failed',
        detail: String((err && err.message) || err),
      });
    }
  });
});

server.listen(PORT, () => {
  console.log('Binance proxy listening on :' + PORT);
});
