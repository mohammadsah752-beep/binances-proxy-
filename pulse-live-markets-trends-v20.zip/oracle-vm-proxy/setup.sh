#!/usr/bin/env bash
# oracle-vm-proxy/setup.sh
#
# Run this ONCE on a fresh Ubuntu Oracle Cloud "Always Free" VM. Paste the
# whole file's contents into one SSH/Termux session, or upload it and run:
#   chmod +x setup.sh && sudo ./setup.sh
#
# It installs Node.js + Caddy, deploys the Binance signing proxy from this
# same folder, opens the ports it needs (Oracle's stock Ubuntu image
# filters ports at the OS level with iptables IN ADDITION to the Security
# List in the console -- opening only one of the two is a common reason
# "it still won't connect" even after following the console instructions),
# and prints the final HTTPS URL to paste into index.html at the end.
set -e

if [ "$(id -u)" -ne 0 ]; then
  echo "Run this with sudo: sudo ./setup.sh"
  exit 1
fi

echo "==> Ensuring curl exists (needed for every step below -- almost always
     already present on Ubuntu cloud images, but this makes it not depend
     on that assumption)..."
apt-get update -qq
apt-get install -y -qq curl

echo "==> Installing Node.js (LTS)..."
curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
apt-get install -y nodejs

echo "==> Installing Caddy (automatic HTTPS, no certbot/nginx needed)..."
apt-get install -y debian-keyring debian-archive-keyring apt-transport-https curl gnupg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
chmod o+r /usr/share/keyrings/caddy-stable-archive-keyring.gpg
chmod o+r /etc/apt/sources.list.d/caddy-stable.list
apt-get update
apt-get install -y caddy

echo "==> Opening ports 80/443 at the OS firewall level (not just the console Security List)..."
# Insert at position 1 (top of the chain), NOT a fixed later position --
# a fixed position like "INPUT 6" assumes at least 5 rules already exist
# on the image, which isn't guaranteed and would abort this whole script
# if wrong. Position 1 is always valid and always wins, since iptables
# stops at the first matching rule and ACCEPT here can't conflict with
# anything else already in the chain.
iptables -C INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || iptables -I INPUT 1 -p tcp --dport 80 -j ACCEPT
iptables -C INPUT -p tcp --dport 443 -j ACCEPT 2>/dev/null || iptables -I INPUT 1 -p tcp --dport 443 -j ACCEPT
netfilter-persistent save 2>/dev/null || (mkdir -p /etc/iptables && iptables-save > /etc/iptables/rules.v4) || true
if command -v ufw >/dev/null 2>&1; then
  ufw allow OpenSSH || true
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true
  ufw --force enable || true
fi

echo "==> Writing the proxy server to /opt/binance-proxy/server.js ..."
mkdir -p /opt/binance-proxy
cat > /opt/binance-proxy/server.js << 'SERVERJS_EOF'
// oracle-vm-proxy/server.js
//
// Same signing logic and same request/response shape as
// cloudflare-worker/binance-live-worker.js, ported to plain Node.js so it
// can run as an always-on process on a dedicated VM instead of a
// shared-IP serverless function. Zero npm dependencies on purpose --
// only Node's own http/https/crypto/url modules -- so `npm install`
// isn't a step that can fail or drift on a fresh server.
'use strict';

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { URL, URLSearchParams } = require('url');

const PORT = process.env.PORT || 8080;
const RECV_WINDOW = 5000;
const BINANCE_BASE = process.env.BINANCE_API_BASE || 'https://api.binance.com';
const BROWSER_USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const ACTIONS = {
  account:                 { method: 'GET',    path: '/api/v3/account',         signed: true },
  openOrders:               { method: 'GET',    path: '/api/v3/openOrders',      signed: true },
  order:                    { method: 'POST',   path: '/api/v3/order',           signed: true },
  oco:                      { method: 'POST',   path: '/api/v3/orderList/oco',   signed: true },
  cancelOrder:               { method: 'DELETE', path: '/api/v3/order',          signed: true },
  cancelOrderList:           { method: 'DELETE', path: '/api/v3/orderList',      signed: true },
  userDataStreamStart:       { method: 'POST',   path: '/api/v3/userDataStream', userStream: true },
  userDataStreamKeepalive:   { method: 'PUT',    path: '/api/v3/userDataStream', userStream: true },
  userDataStreamClose:       { method: 'DELETE', path: '/api/v3/userDataStream', userStream: true },
};

function buildQuery(params) {
  const usp = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') usp.append(k, String(v));
  });
  return usp;
}

function sign(usp, secret) {
  usp.append('timestamp', Date.now());
  usp.append('recvWindow', RECV_WINDOW);
  const qs = usp.toString();
  const signature = crypto.createHmac('sha256', secret).update(qs).digest('hex');
  return qs + '&signature=' + signature;
}

function callBinance(method, path, extraHeaders, body) {
  return new Promise((resolve, reject) => {
    const target = new URL(BINANCE_BASE + path);
    const headers = Object.assign({ 'User-Agent': BROWSER_USER_AGENT }, extraHeaders);
    if (body) headers['Content-Length'] = Buffer.byteLength(body);
    const req = https.request(target, { method, headers }, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.setTimeout(10000, () => req.destroy(new Error('Binance request timed out')));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

function sendJson(res, status, obj) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(obj));
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }
  if (req.method !== 'POST') {
    return sendJson(res, 405, { error: 'Method not allowed' });
  }

  let raw = '';
  req.on('data', (c) => {
    raw += c;
    if (raw.length > 1e6) req.destroy(); // guard against runaway bodies
  });
  req.on('end', async () => {
    let body;
    try {
      body = JSON.parse(raw);
    } catch (e) {
      return sendJson(res, 400, { error: 'Invalid JSON body' });
    }

    const { action, params, apiKey, apiSecret } = body;
    if (!apiKey || !apiSecret) {
      return sendJson(res, 400, {
        error: 'No Binance API key/secret provided.',
        code: 'NO_CREDENTIALS',
        howToFix:
          'Enter your Binance API key and secret in the Live panel — they are sent with each request, never stored on this server.',
      });
    }

    const def = ACTIONS[action];
    if (!def) return sendJson(res, 400, { error: 'Unknown action: ' + action });

    try {
      let path = def.path;
      const headers = { 'X-MBX-APIKEY': apiKey };
      let outBody = null;

      if (def.userStream) {
        const usp = buildQuery(params);
        const qs = usp.toString();
        if (qs) path += '?' + qs;
      } else if (def.signed) {
        const usp = buildQuery(params);
        const signedQs = sign(usp, apiSecret);
        if (def.method === 'GET' || def.method === 'DELETE') {
          path += '?' + signedQs;
        } else {
          headers['Content-Type'] = 'application/x-www-form-urlencoded';
          outBody = signedQs;
        }
      }

      const upstream = await callBinance(def.method, path, headers, outBody);
      let payload = upstream.body;

      if (action === 'userDataStreamStart' && upstream.status < 300) {
        try {
          const parsed = JSON.parse(payload);
          parsed.wsBase = BINANCE_BASE.includes('testnet.binance.vision')
            ? 'wss://stream.testnet.binance.vision'
            : 'wss://stream.binance.com:9443';
          payload = JSON.stringify(parsed);
        } catch (e) {
          /* leave payload as-is if it wasn't JSON */
        }
      }

      res.writeHead(upstream.status, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      });
      res.end(payload);
    } catch (err) {
      sendJson(res, 502, {
        error: 'Upstream request to Binance failed',
        detail: String((err && err.message) || err),
      });
    }
  });
});

server.listen(PORT, () => {
  console.log('Binance proxy listening on :' + PORT);
});
SERVERJS_EOF

echo "==> Installing it as a systemd service (auto-restarts, survives reboots)..."
cat > /etc/systemd/system/binance-proxy.service << 'UNITEOF'
[Unit]
Description=Binance signing proxy
After=network.target

[Service]
ExecStart=/usr/bin/node /opt/binance-proxy/server.js
Restart=always
RestartSec=2
Environment=PORT=8080
User=root

[Install]
WantedBy=multi-user.target
UNITEOF

systemctl daemon-reload
systemctl enable --now binance-proxy

echo "==> Detecting this VM's public IP..."
IPV4_RE='^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$'
PUBLIC_IP=$(curl -s --max-time 10 https://api.ipify.org || true)
if ! echo "$PUBLIC_IP" | grep -qE "$IPV4_RE"; then
  echo "    First lookup (ipify.org) didn't return a usable address -- trying a backup..."
  PUBLIC_IP=$(curl -s --max-time 10 https://ifconfig.me || true)
fi
if ! echo "$PUBLIC_IP" | grep -qE "$IPV4_RE"; then
  echo ""
  echo "================================================================"
  echo " Could not automatically detect this VM's public IP (both lookup"
  echo " services failed to respond -- likely a transient network issue,"
  echo " not a problem with this VM itself)."
  echo ""
  echo " The proxy server and Node.js ARE installed and running -- only"
  echo " the automatic-HTTPS step below was skipped. To finish manually:"
  echo "   1. Find your Public IP in the Oracle Cloud console (Compute >"
  echo "      Instances > this instance)."
  echo "   2. Replace the dots with dashes, e.g. 132.145.67.89 becomes"
  echo "      132-145-67-89"
  echo "   3. Your proxy URL is: https://<that>.sslip.io"
  echo "   4. Re-run this script once your network is stable to have it"
  echo "      configured automatically instead."
  echo "================================================================"
  exit 1
fi

DASHED_IP=$(echo "$PUBLIC_IP" | tr '.' '-')
PROXY_HOSTNAME="${DASHED_IP}.sslip.io"

echo "==> Configuring Caddy for automatic HTTPS on ${PROXY_HOSTNAME} ..."
cat > /etc/caddy/Caddyfile << CADDYEOF
${PROXY_HOSTNAME} {
    reverse_proxy localhost:8080
}
CADDYEOF

systemctl restart caddy
sleep 2

echo ""
echo "================================================================"
echo " DONE."
echo ""
echo " Proxy status:   $(systemctl is-active binance-proxy)"
echo " Caddy status:   $(systemctl is-active caddy)"
echo ""
echo " Your working proxy URL is:"
echo ""
echo "     https://${PROXY_HOSTNAME}"
echo ""
echo " Paste this into index.html's LIVE_HARDCODED_PROXY_URL constant"
echo " yourself, or send it back and it'll be baked in for you."
echo "================================================================"
