# Oracle VM proxy — the free fix that actually reaches Binance

## Why this folder exists

Binance's edge firewall blocks Cloudflare Workers' shared IP pool outright,
before your API key, signature, or headers are even looked at. This isn't
a bug in `cloudflare-worker/binance-live-worker.js` — that code is correct.
It's Binance treating Cloudflare's shared range as a bot-abuse pattern (a
well-documented, ongoing block others have hit with the identical error).

A dedicated VM has its own IP that isn't shared with thousands of other
apps, which is why it doesn't get caught by that block. Oracle Cloud's
"Always Free" tier gives you one of those, forever, at $0.

## What's in this folder

- **server.js** — the same signing logic as the Cloudflare Worker, ported
  to plain Node.js (zero npm dependencies, so there's nothing to fail on
  `npm install`).
- **setup.sh** — installs Node.js + Caddy, deploys `server.js`, opens the
  right ports, and sets up automatic HTTPS. One script, run once.

## Steps

1. **Create the VM.** Go to oracle.com/cloud/free, sign up (a card is
   required for identity verification, but Always Free resources are
   never charged), and create a Compute instance — Ubuntu, "Ampere A1"
   shape if available, otherwise the free "Micro" x86 shape.
2. **Note the public IP** shown on the instance's details page.
3. **SSH in from Termux:**
   ```
   ssh ubuntu@YOUR_VM_PUBLIC_IP
   ```
4. **Get this folder onto the VM.** Easiest way from Termux:
   ```
   scp server.js setup.sh ubuntu@YOUR_VM_PUBLIC_IP:~
   ```
5. **Run it:**
   ```
   chmod +x setup.sh
   sudo ./setup.sh
   ```
6. Wait for it to finish — it prints a URL like:
   ```
   https://123-45-67-89.sslip.io
   ```
   That's your permanent, working proxy URL.
7. Paste that URL into `index.html`'s `LIVE_HARDCODED_PROXY_URL` constant
   (near the top of the `<script>` block), or send it back and it'll be
   baked in for you. Either way, once it's in, the manual "Proxy URL"
   field disappears from the app entirely.

## Notes

- `sslip.io` is a free service that just resolves `A-B-C-D.sslip.io` to
  the IP `A.B.C.D` — no domain purchase or DNS setup needed. Caddy uses
  that hostname to get a real Let's Encrypt certificate automatically.
- If `sudo ./setup.sh` reports port 80/443 already in use, something else
  (e.g. a leftover Apache/Nginx) is already running — stop it first.
- The VM only needs to be reachable on 80 (for the HTTPS certificate
  handshake) and 443 (for everything else). Port 8080 is internal only.
- Your Binance API key/secret are sent from the browser to this server on
  every request and used immediately — never written to disk here.
